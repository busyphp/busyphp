$(function () {
	var $wrap             = $('#uploader'),
		$selectBtn        = $wrap.find('[data-module="upload"]'),
		$selectBtn2       = $wrap.find('[data-module="upload2"]'),
		$dnd              = $wrap.find('[data-module="dnd"]'),
		$tip              = $wrap.find('[data-module="tip"]'),
		// 数据
		data              = $wrap.data(),
		// 附件容器
		$queue            = $('<ul class="filelist"></ul>').appendTo($wrap.find('.queueList')),
		// 状态栏，包括进度和控制按钮
		$statusBar        = $wrap.find('.statusBar'),
		// 文件总体选择信息。
		$info             = $statusBar.find('.info'),
		// 上传按钮
		$upload           = $wrap.find('.uploadBtn'),
		// 没选择文件之前的内容。
		$placeHolder      = $wrap.find('.placeholder'),
		// 总体进度条
		$progress         = $statusBar.find('.progress').hide(),
		// 添加的文件数量
		fileCount         = 0,
		// 添加的文件总大小
		fileSize          = 0,
		// 优化retina, 在retina下这个值是2
		ratio             = window.devicePixelRatio || 1,
		// 缩略图大小
		thumbnailWidth    = 110 * ratio,
		thumbnailHeight   = 110 * ratio,
		// 可能有pedding, ready, uploading, confirm, done.
		state             = 'pedding',
		// 所有文件的进度信息，key为file id
		percentages       = {},
		supportTransition = (function () {
			var s = document.createElement('p').style,
				r = 'transition' in s ||
					'WebkitTransition' in s ||
					'MozTransition' in s ||
					'msTransition' in s ||
					'OTransition' in s;
			s     = null;
			return r;
		})();

	data.markType       = data.markType || 'file';
	data.markValue      = data.markValue || '';
	var fileConfig      = window.FILE_CLASS[data.markType];
	var uploaderChunked = false;

	// 实例化
	var obj = new WebUploader.Uploader({
		paste               : document.body,
		swf                 : window.UPLOADIFY_SWF_URL,
		server              : window.UPLOADIFY_URL,
		auto                : false,
		fileVal             : 'upload',
		method              : 'POST',
		dnd                 : $dnd[0],
		disableGlobalDnd    : true,
		chunked             : true,
		chunkSize           : 5242880,
		threads             : 3,
		fileSingleSizeLimit : fileConfig.size <= 0 ? undefined : fileConfig.size,
		duplicate           : false,
		compress            : false,
		pick                : {
			id       : $selectBtn[0],
			multiple : true
		},
		formData            : {
			stamp      : window.UPLOADIFY_STAMP,
			sid        : window.UPLOADIFY_SID,
			mark_type  : data.markType || '',
			mark_value : data.markValue || ''
		},
		accept              : {
			title      : '选择' + fileConfig.name,
			extensions : fileConfig.suffix,
			mimeTypes  : fileConfig.mime
		}
	});

	// 文件加入列队
	obj.on('fileQueued', function (file) {
		fileCount++;
		fileSize += file.size;
		if (fileCount === 1) {
			$placeHolder.addClass('element-invisible');
			$statusBar.show();
		}
		addFile.call(this, file);
		setState('ready');
		updateTotalProgress();
		return false;
	});

	// 当某个文件的分块在发送前触发，主要用来询问是否要添加附带参数，大文件在开起分片上传的前提下此事件可能会触发多次。
	obj.on('uploadBeforeSend', function (object, data, headers) {
		uploaderChunked = object.chunks !== 1;
	});

	// 某个文件开始上传前触发，一个文件只会触发一次。
	obj.on('uploadStart', function (file) {
		this.option('formData', {guid : file.source.uid, is_complete : 0});
	});

	// 上传中
	obj.on('uploadProgress', function (file, percentage) {
		var $item = getItem(file).find('[role="progress"]');
		$item.css('display', 'block');
		$item.css('width', (percentage * 100).toFixed(2) + '%');
		percentages[file.id][1] = percentage;
		updateTotalProgress();
	});

	// 上传成功
	obj.on('uploadSuccess', function (file) {
		if (uploaderChunked) {
			console.log("分片上传完成");
			var params         = obj.option('formData');
			params.is_complete = 1;
			params.filename    = file.name;
			$.post(obj.option('server'), params, function (data) {
				if (data.status) {
					file.setStatus('complete');
				} else {
					file.setStatus('error', data.info);
				}
			}, 'json');
		} else {
			file.setStatus('complete');
		}
		return false;
	});

	// 上传失败
	obj.on('uploadError', function (file, info) {
		file.setStatus('error', $.parseUploaderError(info));
		return false;
	});

	// 错误
	obj.on('error', function (info) {
		$.dialog.alert($.parseUploaderCode(info));
	});

	// 文件被移除
	obj.on('fileDequeued', function (file) {
		fileCount--;
		fileSize -= file.size;
		if (!fileCount) {
			setState('pedding');
		}
		removeFile.call(this, file);
		updateTotalProgress();
		return false;
	});

	// 所有文件上传完成
	obj.on('uploadFinished', function () {
		setState('confirm');
	});

	// 开始上传
	obj.on('startUpload', function () {
		setState('uploading');
	});

	// 开始上传
	obj.on('stopUpload', function () {
		setState('paused');
	});

	var template = '<li>\
					<p class="title"></p>\
					<p class="imgWrap" role="thumb"></p>\
					<p class="progress"><span role="progress"></span></p>\
					<div class="file-panel" role="btns">\
						<span class="cancel" role="close">删除</span>\
						<span class="rotateRight">向右旋转</span>\
						<span class="rotateLeft">向左旋转</span>\
					</div>\
					<span class="success" style="display:none" role="success"></span>\
					<p class="error" style="display:none" role="status"></p>\
				</li>';

	function createItem(file) {
		var $item = $(template);
		$item.attr('id', 'Upload_' + file.id);
		$item.find('.title').text(file.name);
		$queue.append($item);
		return $item;
	}

	function getItem(file) {
		return $('#Upload_' + file.id);
	}

	function addFile(file) {
		var me        = this,
			$li       = createItem(file),
			$btns     = $li.find('[role="btns"]'),
			$wrap     = $li.find('[role="thumb"]'),
			$info     = $li.find('[role="status"]'),
			$success  = $li.find('[role="success"]'),
			showError = function (code) {
				switch (code) {
					case 'exceed_size':
						text = '文件大小超出';
						break;
					case 'interrupt':
						text = '上传暂停';
						break;
					default:
						text = code;
						break;
				}
				$info.text(text).show();
				$success.hide();
			};
		if (file.getStatus() === 'invalid') {
			showError(file.statusText);
		} else {
			$wrap.text('预览中');
			me.makeThumb(file, function (error, src) {
				if (error) {
					$wrap.text('不能预览');
					return;
				}
				var img = $('<img src="' + src + '">');
				$wrap.empty().append(img);
			}, thumbnailWidth, thumbnailHeight);
			percentages[file.id] = [file.size, 0];
			file.rotation        = 0;
		}

		// 绑定文件改变事件
		file.on('statuschange', function (cur, prev) {
			if (prev === 'progress') {
				$li.find('[role="progress"]').hide();
			} else if (prev === 'queued') {
				$li.off('mouseenter mouseleave');
				$btns.remove();
			}

			// 成功
			$li.find('[role="success"]').hide();
			if (cur === 'error' || cur === 'invalid') {
				showError(file.statusText);
				percentages[file.id][1] = 1;
			} else if (cur === 'interrupt') {
				showError('interrupt');
			} else if (cur === 'queued') {
				percentages[file.id][1] = 0;
			} else if (cur === 'progress') {
				$info.hide();
				$success.hide();
			} else if (cur === 'complete') {
				$success.show();
				$info.hide();
			}
			$li.removeClass('state-' + prev).addClass('state-' + cur);
		});

		$li.on('mouseenter', function () {
			$btns.stop().animate({height : 30});
		});
		$li.on('mouseleave', function () {
			$btns.stop().animate({height : 0});
		});
		$btns.on('click', 'span', function () {
			var index = $(this).index(), deg;
			switch (index) {
				case 0:
					me.removeFile(file);
					return;
				case 1:
					file.rotation += 90;
					break;
				case 2:
					file.rotation -= 90;
					break;
			}
			if (supportTransition) {
				deg = 'rotate(' + file.rotation + 'deg)';
				$wrap.css({
					'-webkit-transform' : deg,
					'-mos-transform'    : deg,
					'-o-transform'      : deg,
					'transform'         : deg
				});
			} else {
				$wrap.css('filter', 'progid:DXImageTransform.Microsoft.BasicImage(rotation=' + (~~((file.rotation / 90) % 4 + 4) % 4) + ')');
			}
		});
	}

	function updateTotalProgress() {
		var loaded = 0,
			total  = 0,
			spans  = $progress.children(),
			percent;
		$.each(percentages, function (k, v) {
			total += v[0];
			loaded += v[0] * v[1];
		});
		percent = total ? loaded / total : 0;
		spans.eq(0).text(Math.round(percent) + '%');
		spans.eq(1).css('width', Math.round(percent) + '%');
		updateStatus();
	}

	function updateStatus() {
		var text = '', stats;
		if (state === 'ready') {
			text = '选中' + fileCount + '个附件，共' + WebUploader.formatSize(fileSize) + '。';
		} else if (state === 'confirm') {
			stats = obj.getStats();
			if (stats.uploadFailNum) {
				text = '已成功上传' + stats.successNum + '个附件，' + stats.uploadFailNum + '个附件上传失败，<a class="retry" href="#">重新上传</a>失败附件';
			}
		} else {
			stats = obj.getStats();
			text  = '共' + fileCount + '个（' + WebUploader.formatSize(fileSize) + '），已上传' + stats.successNum + '个';
			if (stats.uploadFailNum) {
				text += '，失败' + stats.uploadFailNum + '个';
			}
		}
		$info.html(text);
	}

	function setState(val) {
		var file, stats;
		if (val === state) {
			return;
		}
		$upload.removeClass('state-' + state);
		$upload.addClass('state-' + val);
		state = val;
		switch (state) {
			case 'pedding':
				$placeHolder.removeClass('element-invisible');
				$queue.parent().removeClass('filled');
				$queue.hide();
				$statusBar.addClass('element-invisible');
				obj.refresh();
				break;
			case 'ready':
				$placeHolder.addClass('element-invisible');
				$selectBtn2.removeClass('element-invisible');
				$queue.parent().addClass('filled');
				$queue.show();
				$statusBar.removeClass('element-invisible');
				obj.refresh();
				break;
			case 'uploading':
				$selectBtn2.addClass('element-invisible');
				$progress.show();
				$upload.text('暂停上传');
				break;
			case 'paused':
				$progress.show();
				$upload.text('继续上传');
				break;
			case 'confirm':
				$progress.hide();
				$upload.text('开始上传').addClass('disabled');
				stats = obj.getStats();
				if (stats.successNum && !stats.uploadFailNum) {
					setState('finish');
					return;
				}
				break;
			case 'finish':
				stats = obj.getStats();
				if (stats.successNum) {
					$.dialog.alert('所有附件上传成功！', function () {
						self.location.reload();
					});
				} else {
					// 没有成功的图片，重设
					state = 'done';
					self.location.reload();
				}
				break;
		}
		updateStatus();
	}

	// 负责view的销毁
	function removeFile(file) {
		var $li = getItem(file);
		delete percentages[file.id];
		updateTotalProgress();
		$li.off().find('.file-panel').off().end().remove();
	}

	// 添加“添加文件”的按钮，
	obj.addButton({
		id    : $selectBtn2[0],
		label : '继续添加'
	});

	$upload.on('click', function () {
		if ($(this).hasClass('disabled')) {
			return false;
		}
		if (state === 'ready') {
			obj.upload();
		} else if (state === 'paused') {
			obj.upload();
		} else if (state === 'uploading') {
			//console.log('stop');
			obj.stop();
		}
	});
	$info.on('click', '.retry', function () {
		obj.retry();
	});
	$info.on('click', '.ignore', function () {
		alert('todo');
	});
	$upload.addClass('state-' + state);
	updateTotalProgress();

	$tip.html($.parseUploaderDesc(fileConfig));
});