(function ($) {
	var BAreaSelect = function ($province, trees) {
		this.province        = $province;
		this.provinceDefault = $.trim(this.province.attr('data-default') || '请选择省份');
		this.provinceValue   = $.trim(this.province.attr('data-value') || '');
		this.provinceIndex   = -1;
		this.city            = $(this.province.attr('data-child'));
		this.cityDefault     = $.trim(this.city.attr('data-default') || '请选择城市');
		this.cityValue       = $.trim(this.city.attr('data-value') || '');
		this.cityIndex       = -1;
		this.district        = $(this.city.attr('data-child'));
		this.districtDefault = $.trim(this.district.attr('data-default') || '请选择区县');
		this.districtValue   = $.trim(this.district.attr('data-value') || '');
		this.districtIndex   = -1;
		this.isInit          = true;
		this.trees           = trees;
		this._init();
	};

	BAreaSelect.prototype._init = function () {
		var me = this;

		this.adapter(this.province, this.trees, this.provinceDefault, this.provinceValue);
		this.reset(this.city, this.cityDefault);
		this.reset(this.district, this.districtDefault);

		// 绑定事件
		this.province.on('change', function () {
			var index        = parseInt($(this).find(':selected').attr('data-index'));
			me.provinceIndex = isNaN(index) ? -1 : index;
			if (me.provinceIndex < 0) {
				me.reset(me.city, me.cityDefault);
			} else {
				me.adapter(me.city, me.trees[me.provinceIndex].child, me.cityDefault, me.cityValue);
				me.reset(me.district, me.districtDefault);
				if (me.isInit) {
					me.isInit = false;
					me.city.trigger('change');
				}
			}
		});

		this.city.on('change', function () {
			var index    = parseInt($(this).find(':selected').attr('data-index'));
			me.cityIndex = isNaN(index) ? -1 : index;
			if (me.cityIndex < 0) {
				me.reset(me.district, me.districtDefault);
			} else {
				me.adapter(me.district, me.trees[me.provinceIndex].child[me.cityIndex].child, me.districtDefault, me.districtValue);
			}
		});

		this.province.trigger('change');
	};

	/**
	 * 绘制Options
	 */
	BAreaSelect.prototype.adapter = function (target, data, defaultText, selectedValue) {
		var options = '<option value="0" data-index="-1">' + defaultText + '</option>', i, length = data.length;
		if (length > 0) {
			for (i = 0; i < data.length; i++) {
				var selected = '';
				if (data[i].id == selectedValue) {
					selected = ' selected';
				}
				options += '<option value="' + data[i].id + '" data-index="' + i + '"' + selected + '>' + data[i].name + '</option>';
			}
//			console.log(target, options);
			target.removeClass('disabled').prop('disabled', false).html(options);
//			console.log(target.html());
		} else {
			this.reset(target, defaultText);
		}
	};

	/**
	 * 重置
	 * @param target
	 * @param defaultText
	 */
	BAreaSelect.prototype.reset = function (target, defaultText) {
		target.prop('disabled', true).addClass('disabled').html('<option value="-1">' + defaultText + '</option>');
	};

	$.fn.BAreaSelect = function (data) {
		return new BAreaSelect($(this), data);
	};
})(jQuery);