;(function ($, window) {
	/**
	 * dialog模板
	 */
	$.dialog._templates = '<div class="aui_outer">\
		<div class="aui_inner">\
			<div class="modal-dialog aui_dialog">\
				<div class="modal-content">\
					<div class="modal-header">\
						<div class="aui_titleBar">\
							<a href="javascript:void(0)" class="close aui_close">&times;</a>\
							<h4 class="modal-title aui_title"></h4>\
						</div>\
					</div>\
					<div class="modal-body">\
						<table class="aui_table">\
							<tr>\
								<td class="aui_icon"><div class="aui_iconBg"></div></td>\
								<td class="aui_main"><div class="aui_content"></div></td>\
							</tr>\
						</table>\
					</div>\
					<div class="modal-footer aui_footer">\
						<div class="aui_buttons"></div>\
					</div>\
					<div class="aui_se"></div>\
				</div>\
			</div>\
		</div>\
	</div>';
	/**
	 * 为dialog添加bootstarp样式
	 */
	$.dialog.defaults.init = function () {
		var that = this;
		// 按钮
		that.DOM.buttons.find('button').each(function () {
			var $this = $(this).addClass('btn');
			if ($this.hasClass('aui_state_highlight')) {
				$this.addClass('btn-success');
			} else {
				$this.addClass('btn-default');
			}
		});
		// 按钮容器
	};
	/**
	 * dialog 设置 button方法，为按钮追加bootstarp样式
	 */
	$.dialog.fn.set_button = function (button) {
		if ($.isArray(button)) {
			for (var k in button) {
				if (button[k].focus) {
					button[k].className = 'btn btn-success';
				} else {
					button[k].className = 'btn btn-default';
				}
			}
		} else {
			if (button.focus) {
				button.className = 'btn btn-success';
			} else {
				button.className = 'btn btn-default';
			}
		}
		//console.log(button);
		return this.button(button);
	};
	/**
	 * 弹出提示框询问后执行GET提交操作
	 * 不适用FORM表单
	 * 适用与单个链接操作
	 * @param {Object} element 执行操作的元素jQuery对象，用于回调
	 * @param {Object} options 配置参数
	 * @returns {$}
	 */
	$.confirmGetSubmit = function (element, options) {
		var $loading,
			options  = options || {},
			defaults = {
				message    : '确认要删除？',
				loading    : '删除中，请稍候...',
				ajaxSubmit : true,
				actionURL  : '',
				success    : null,
				error      : null,
				enter      : null,
				cancel     : null
			},
			settings = $.extend({}, defaults, options);
		// 执行中
		if (true === element.data('state')) {
			return this;
		}
		// 设置执行状态
		element.data('state', true);
		// confirm 提示
		$.dialog.confirm(settings.message, function () {
			if (settings.enter) {
				if (typeof settings.enter === "function" && false === settings.enter.call(element)) {
					element.data('state', false);
					return true;
				} else if (typeof settings.enter === "string" && false === eval(settings.enter + '.call(element);')) {
					element.data('state', false);
					return true;
				}
			}
			// AJAX提交
			if (settings.ajaxSubmit) {
				$loading = $.dialog.pending(settings.loading);
				$.getInfo(settings.actionURL, function (data) {
					$loading.close();
					element.data('state', false);
					$.dialog.alert(data.info, function () {
						// 成功回调
						if (settings.success) {
							if (typeof settings.success === "function" && false === settings.success.call(element, data)) {
								return true;
							} else if (typeof settings.success === "string" && false === eval(settings.success + '.call(element, data)')) {
								return true;
							}
						}
						self.location.reload();
					});
				}, function (data) {
					$loading.close();
					element.data('state', false);
					$.dialog.alert(data.info, function () {
						// 失败回调
						if (settings.error) {
							if (typeof settings.error === "function") {
								settings.error.call(element, data);
							} else if (typeof settings.callback === "string") {
								eval(settings.error + '.call(element, data)');
							}
							return;
						}
					});
				});
			}
			// 普通跳转提交
			else {
				self.location.href = settings.actionURL;
			}
		}, function () {
			if (settings.cancel) {
				if (typeof settings.cancel === "function" && false === settings.cancel.call(element)) {
					return true;
				} else if (typeof settings.cancel === "string" && false === eval(settings.cancel + '.call(element);')) {
					return true;
				}
			}
			element.data('state', false);
		});
		return element;
	};
	/**
	 * 获取atrDialog API
	 */
	$.dialogApi = function () {
		return {
			parent  : $.dialog.parent,
			through : $.dialog.through,
			origin  : $.dialog.open.origin,
			top     : $.dialog.top,
			opener  : $.dialog.opener,
			api     : $.dialog.open.api
		};
	};

	/**
	 * 获取随机字符串
	 * @param {Number} line 字符串长度
	 * @param {Function} callback 获取成功的回调函数
	 * @example
	 * $.getRandString(10, function(value){
	 *		 alert(value); // 返回10位随机字符串
	 * })
	 */
	$.getRandString = function (line, callback) {
		$.post(ADMIN_URL + 'Common.Action/rand', {line : line}, function (data) {
			callback(data.data);
		});
	};

	/**
	 * 打开进度条
	 */
	$.progress = function (options) {
		var defaults = {
				title    : '处理中...',
				link     : document.URL,
				message  : '正在处理中，请稍后...',
				firstLog : '开始处理',
				success  : function () {
				}
			},
			settings = $.extend({}, defaults, options || {});
		//console.log(settings);
		$.dialog({
			content : '<div class="progress-pop" id="progressPop">' +
			'<div class="progress">' +
			'<div class="progress-bar progress-bar-success progress-bar-striped"><span>0%</span></div>' +
			'</div>' +
			'<p class="message">' + settings.message + '</p>' +
			'<textarea class="form-control" rows="6" readonly="readonly">' + settings.firstLog + '</textarea>' +
			'</div>',
			id      : 'progressPop',
			title   : settings.title,
			padding : 0,
			esc     : false,
			cancel  : false,
			init    : function () {
				var me = this, code, progress = 0,
					$wrap                     = $('#progressPop'),
					$progress                 = $wrap.find('.progress-bar'),
					$status                   = $progress.find('span'),
					$message                  = $wrap.find('.message'),
					$text                     = $wrap.find('textarea'),
					request                   = function (link) {
						$.getInfo(link, function (data) {
							code = data.data;
							// 进行中...
							if (code.state === 'PROGRESS') {
								// 每次执行完成的状态
								if (data.info) {
									$message.html(data.info);
								}
								// 每次执行完的记录
								if (code.log) {
									$text.val($text.val() + "\r\n" + code.log);
									$text[0].scrollTop = $text[0].scrollHeight;
								}
								// 进度计算
								progress = parseInt((code.progress / code.total).toFixed(2) * 100);
								$progress.css('width', progress + '%');
								$status.text(progress + '%');
								//console.log(progress);
								// 下一个进度
								request(data.url);
							}

							// 备份完成
							else if (code.state === 'SUCCESS') {
								$.dialog.alert(data.info, function () {
									if (typeof settings.success === "function" && false === settings.success.call(me, data)) {
										return true;
									}
									self.location.href = data.url;
								}, 'succeed');
							}

							// 其他
							else {
								$.dialog.alert('未知错误！');
							}
						}, function (data) {
							$.dialog.alert(data.info);
						});
					}
				request(settings.link);
			}
		});
	};

	/**
	 * 获取模型
	 * @param name
	 * @return {jQuery}
	 */
	$.fn.M = function (name) {
		return $(this).find('[data-module="' + name + '"]');
	};

	/**
	 * 自动添加列
	 * @constructor
	 */
	var AdminAddItem = function ($element) {
		this.$element        = $element;
		this.data            = $element.data();
		this.data.maxLength  = parseInt(this.data.maxLength || 0);
		this.data.maxLength  = isNaN(this.data.maxLength) ? 0 : this.data.maxLength;
		this.data.initLength = parseInt(this.data.initLength || 0);
		this.data.initLength = isNaN(this.data.initLength) ? 0 : this.data.initLength;
		this.$addBtn         = $(this.data.target);
		this.$wrap           = $(this.data.wrap);
		this.bindEvents      = {};
		this.index           = 0;
		this.itemLength      = this.$wrap.M('item').length;

		this.init();
	};

	/**
	 * 执行初始化
	 * @return {AdminAddItem}
	 */
	AdminAddItem.prototype.init = function () {
		var me = this;
		this.$addBtn.on('click', function () {
			me.addItem();
		});

		if (this.data.initLength < 1) {
			return this;
		}

		if (this.itemLength === 0) {
			for (var i = 0; i < this.data.initLength; i++) {
				this.addItem();
			}
		} else {
			this.$wrap.M('item').each(function () {
				me.bindItemEvent($(this));
			});
			this.refreshList();
		}

		return this;
	};

	/**
	 * 创建一个列队
	 * @return {jQuery}
	 */
	AdminAddItem.prototype.createItem = function () {
		var $item = $(this.$element.html());
		this.index++;
		this.itemLength++;

		return $item;
	};

	/**
	 * 刷新组件
	 */
	AdminAddItem.prototype.refreshList = function () {
		var index = 0;
		var me    = this;
		this.$wrap.M('item').each(function () {
			$(this).find('[data-name]').each(function () {
				var value = $(this).data('name');
				var arr   = value.split(':');
				var attr  = 'name';
				if (arr.length === 2) {
					attr  = arr[0];
					value = arr[1];
				} else {
					value = arr[0];
				}
				switch (attr) {
					case 'text':
						value = value.replace(/\[num\]/g, index + 1);
						$(this).text(value);
						break;
					default:
						value = value.replace(/\[num\]/g, index);
						$(this).attr(attr, value);
				}
			});
			$(this).data('index', index);
			me.triggerEvent('item.reset', $(this));
			index++;
		});
	};

	/**
	 * 添加一组列队
	 * @return {AdminAddItem}
	 */
	AdminAddItem.prototype.addItem = function () {
		var me    = this;
		var $item = this.createItem();

		// 最大条数
		if (this.data.maxLength > 0 && this.itemLength > this.data.maxLength) {
			this.itemLength--;
			$.dialog.alert('最多允许添加' + this.data.maxLength + '条记录');

			return this;
		}

		this.bindItemEvent($item);
		this.triggerEvent('item.before', $item);
		this.$wrap.append($item);
		this.triggerEvent('item.after', $item);
		this.refreshList();

		return this;
	};

	AdminAddItem.prototype.bindItemEvent = function ($item) {
		var me = this;

		// 删除
		$item.M('remove').on('click', function () {
			me.triggerEvent('remove.before', $item);
			$item.remove();
			me.refreshList();
			me.itemLength--;
			me.triggerEvent('remove.after', $item);
		});

		// 上移动
		$item.M('prev').on('click', function () {
			var $prev = $item.prev();
			if ($prev.length === 0) {
				$.dialog.alert('无法在向上移动了');
				return false;
			}

			me.triggerEvent('prev.before', $item);
			$prev.before($item);
			me.refreshList();
			me.triggerEvent('prev.after', $item);
		});

		// 下移动
		$item.M('next').on('click', function () {
			var $next = $item.next();
			if ($next.length === 0) {
				$.dialog.alert('无法在向下移动了');
				return false;
			}

			me.triggerEvent('next.before', $item);
			$next.after($item);
			me.refreshList();
			me.triggerEvent('next.after', $item);
		});

		return this;
	};

	/**
	 * 绑定事件
	 * @param eventName
	 * @param callback
	 * @return {AdminAddItem}
	 */
	AdminAddItem.prototype.bind = function (eventName, callback) {
		this.bindEvents[eventName] = callback;
		return this;
	};

	/**
	 * 触发绑定事件
	 * @param eventName
	 * @param args
	 */
	AdminAddItem.prototype.triggerEvent = function (eventName, args) {
		var event = this.bindEvents[eventName] || null;
		if (typeof event === 'function') {
			return event.call(this, args);
		}

		return null;
	};

	$.fn.adminAddItem = function () {
		if (true === this.data('isAdminAddItem')) {
			return this.data('adminAddItem');
		}

		var addItem = new AdminAddItem($(this));
		this.data('isAdminAddItem', true);
		this.data('adminAddItem', addItem);
		return addItem;
	};

})(jQuery, window);
/**
 * 页面初始化执行的自动化的方法
 */
$(document).ready(function () {

	// +--------------------------------------
	// | 以下为自动组件，通过指定的data属性
	// +--------------------------------------
	/**
	 * 自动日历
	 * @import /data/plugin/date/WdatePicker.js
	 * @attr data-date
	 * @attr role-format 值为日期格式
	 * @attr role-min-date-selector 最小日期对应的选择器
	 * @attr role-max-date-selector 最大日期对应的选择器
	 * @attr role-min-date 最小日期
	 * @attr role-max-date 最大日期
	 * @example
	 * <input type="text" data-date="" />
	 * <input type="text" data-date="yyyy-MM-dd" />
	 * <input type="text" data-date="yyyy-MM-dd HH:mm:ss" />
	 */
	$(document).on('focus.data_date', '[data-date]', function () {
		var $this           = $(this),
			dateFmt         = $this.getRoleValue('format') || $this.getDataValue('date'),
			dateFmt         = dateFmt || 'yyyy-MM-dd HH:mm:ss',
			minDate         = $this.getRoleValue('min-date') || false,
			maxDate         = $this.getRoleValue('max-date') || false,
			minDateSelector = $this.getRoleValue('min-date-selector') || false,
			maxDateSelector = $this.getRoleValue('max-date-selector') || false;
		var settings        = {
			el      : this,
			dateFmt : dateFmt
		};
		if (minDate) {
			settings['minDate'] = minDate;
		} else if (minDateSelector) {
			$target = $(minDateSelector);
			if ($target.length && $target.val()) {
				settings['minDate'] = $target.val();
			}
		}
		if (maxDate) {
			settings['maxDate'] = maxDate;
		} else if (maxDateSelector) {
			$target = $(maxDateSelector);
			if ($target.length && $target.val()) {
				settings['maxDate'] = $target.val();
			}
		}
		WdatePicker(settings);
	});
	/**
	 * 自动颜色组件，
	 * @import /data/plugin/color/js.js
	 * @import /data/plugin/color/css.css
	 * @attr data-color
	 * @example
	 * <input type="text" data-color="" />
	 */
	$(document).on('focus.data_color', '[data-color]', function () {
		$(this).bigColorpicker();
	});
	/**
	 * 自动随机字符串组件
	 * @attr data-rand
	 * @attr role-length 字符串长度
	 * @attr role-target 接收字符串的表单容器
	 * @attr role-tip 加载中按钮的提示文字
	 * @example
	 * <input type="text" id="demo"/>
	 * <input type="button" data-rand="6" role-target="#demo"/>
	 */
	$(document).on('click.data_rand', "[data-rand]", function () {
		var $this   = $(this),
			$target = $($this.getRoleValue('target')),
			line    = $this.getRoleValue('length') || $this.getDataValue('rand'),
			tip     = $this.getRoleValue('tip') || '请稍后',
			defTip  = $this.val() || $this.text(),
			tagName = $this[0].tagName;
		if ($this.prop('disabled')) {
			return false;
		}
		$this.prop('disabled', true);
		if (tagName === 'INPUT') {
			$this.val(tip);
		} else {
			$this.html(tip);
		}
		$.getRandString(line, function (data) {
			$this.prop('disabled', false);
			if (tagName === 'INPUT') {
				$this.val(defTip);
			} else {
				$this.html(defTip);
			}
			$target.val(data);
		});
	});
	/**
	 * table 中自动 checkbox 选中，会创建全局变量
	 * @attr data-table-checkbox 值为对应组件的全局变量的后缀，为空则默认为global，如 checkbox_global
	 * @attr role-checkbox-callback {selectCheckBox} 配置，请使用object的格式配置，可以覆盖默认配置
	 * @children 子容器功能属性
	 *        @attr role-checkbox="control" 全选或者反选的容器
	 *        @attr role-checkbox="item" 被选择的checkbox
	 * @example
	 * <table data-table-checkbox="global" role-checkbox->
	 *     <tr><td><input type="checkbox" role-checkbox="control"/>全选</td></tr>
	 *     <tr><td><input type="checkbox" role-checkbox="item"/>列表</td></tr>
	 *     <tr><td><input type="checkbox" role-checkbox="item"/>列表</td></tr>
	 * </table>
	 */
	$("[data-table-checkbox]").each(function () {
		var $this    = $(this),
			group    = $this.getDataValue('table-checkbox') || 'global',
			callback = $this.getRoleValue('checkbox-callback') || '',
			$control = $this.find("[role-checkbox='control']"),
			$queue   = $this.find("[role-checkbox='item']"),
			options  = {
				queue           : $queue,
				singleSelection : function (element) {
					$(element).closest('tr').addClass('info');
				},
				singleCancelled : function (element) {
					$(element).closest('tr').removeClass('info');
				},
				allSelected     : function () {
					$this.find('tbody tr').addClass('info');
				},
				allCancelled    : function () {
					$this.find('tbody tr').removeClass('info');
				}
			};
		if (callback.indexOf('{') !== -1) {
			callback = eval('(' + callback + ')');
			options  = $.extend({}, options, callback);
		}
		window['checkbox_' + group] = $control.selectCheckBox(options);
	});
	/**
	 * 点击get提交绑定
	 * @attr data-get-confirm    启动属性，值为确认弹窗提示消息
	 * @attr role-ajax            使用ajax提交
	 * @attr role-href|href        提交的URL
	 * @attr role-loading        ajax提交中弹出等待框的提示文字
	 * @attr role-success        ajax提交成功后的回调事件
	 * @attr role-error            ajax提交失败后的回调事件
	 * @attr role-enter            点击确认提示后的回调函数，返回false则不执行get提交
	 * @attr role-cancel        点击取消提示后的回调函数，
	 * @example
	 * <a href="http://example/geturl" data-get-confirm="确认要删除吗？"></a>
	 */
	$(document).on('click.data_get_confirm', '[data-get-confirm]', function () {
		var $this = $(this),
			href  = $this.attr('href');
		href      = href.indexOf('javascript:') != -1 ? $this.getRoleValue('href') : href;
		$.confirmGetSubmit($this, {
			message    : $this.getDataValue('get-confirm') || '确认要删除？',
			loading    : $this.getRoleValue('loading') || '删除中，请稍候...',
			ajaxSubmit : $this.getRoleValue('ajax') ? true : false,
			actionURL  : href,
			success    : $this.getRoleValue('success'),
			error      : $this.getRoleValue('error'),
			cancel     : $this.getRoleValue('cancel'),
			enter      : $this.getRoleValue('enter')
		});
		return false;
	});
	/**
	 * 自动化列队表单提交，适用于批量删除或者批量操作列队使用
	 * @attr data-queue-post-confirm    启动属性，值为确认弹窗提示消息
	 * @attr role-loading        提交中弹出等待框的提示文字
	 * @attr role-before        提交前的回调事件，返回false则不验证checkbox选中项目
	 * @attr role-success        提交成功后的回调事件
	 * @attr role-error            提交失败后的回调事件
	 * @attr role-empty-infos    没有选中信息的提示内容
	 * @attr role-complete        提交完成的回调事件
	 * @attr role-enter            点击确认提示后的回调函数，返回false则不执行提交
	 * @attr role-cancel        点击取消提示后的回调函数，
	 * @example
	 * <form action="http://example/posturl" data-queue-post-confirm="确认要删除选中信息吗？"></form>
	 */
	$("[data-queue-post-confirm]").each(function () {
		var $this   = $(this),
			$button = $this.find("[type='submit']"),
			$loading;
		$this.data('status', 'pending').submitForm({
			before  : function () {
				var state,
					validate    = true,
					before      = $this.getRoleValue('before'),
					loading     = $this.getRoleValue('loading') || '正在删除中，请稍后...',
					confirm     = $this.getDataValue('queue-post-confirm') || '确认要删除选中信息吗？',
					empty_infos = $this.getRoleValue('empty-infos') || '请选择一条要操作的信息！',
					enter       = $this.getRoleValue('enter'),
					cancel      = $this.getRoleValue('cancel'),
					checkbox    = $this.getDataValue('table-checkbox') || 'global',
					checkbox    = 'checkbox_' + checkbox;
				// 加载中
				if ($this.data('status') === 'loading') {
					return false;
				}
				// 提交前回调，返回FLASE则不验证checkbox
				if (before.length && false === eval(before + '.call($this)')) {
					validate = false;
				}
				// 验证checkbox
				if (true === validate && window[checkbox] && false === window[checkbox].getStatus()) {
					$.dialog.alert(empty_infos);
					return false;
				}
				// 提交
				if ($this.data('status') === 'submit') {
					$this.data('status', 'loading');
					$loading = $.dialog.pending(loading);
					$button.prop('disabled', true);
					return true;
				}
				// 确认操作
				if ($this.data('status') === 'pending') {
					$.dialog.confirm(confirm, function () {
						// 确认回调
						if (enter.length && false === eval(enter + '.call($this);')) {
							return true;
						}
						$this.data('status', 'submit');
						$this.submit();
					}, function () {
						// 取消回调
						if (cancel.length && false === eval(cancel + '.call($this);')) {
							return true;
						}
						$this.data('status', 'pending');
					});
				}
				return false;
			},
			success : function (data) {
				var success = $this.getRoleValue('success');
				$.dialog.alert(data.info, function () {
					if (success.length && false === eval(success + '.call($this, data);')) {
						return true;
					}
					self.location.reload();
				}, 'succeed');
			},
			error   : function (data) {
				var error = $this.getRoleValue('error');
				$.dialog.alert(data.info, function () {
					if (error) {
						eval(error + '.call($this, data)');
					}
				});
			},
			after   : function (data) {
				var complete = $this.getRoleValue('complete');
				$loading.close();
				$button.prop('disabled', false);
				$this.data('status', 'pending');
				if (complete) {
					eval(complete + '.call($this, data)');
				}
			}
		});
	});

	/**
	 * 自动化表单POST提交
	 * @attr data-post 启动属性，值为确认弹窗提示消息
	 * @attr role-loading 提交中弹出等待框的提示文字
	 * @attr role-before 提交前的回调事件，返回false则不提交
	 * @attr role-success  提交成功后的回调事件
	 * @attr role-error 提交失败后的回调事件
	 * @attr role-complete 提交完成的回调事件，不管成功或失败都执行该
	 * @attr role-enter 点击确认提示后的回调函数，返回false则不执行提交
	 * @attr role-cancel 点击取消提示后的回调函数
	 * @attr role-use 提交模式，1为自定义模式，否则为系统模式，以上的回调均不可使用
	 * @example
	 * <form action="http://example/posturl" data-post="确认要删除选中信息吗？"></form>
	 */
	$("[data-post]").each(function () {
		var $this         = $(this),
			$button       = $this.find("[type='submit']"),
			$loading, use = parseInt($this.getRoleValue('use')) || 0;
		if (use) {

			// 绑定提交
			$this.data('status', 'pending').submitForm({
				// 提交前
				before  : function () {
					var before  = $this.getRoleValue('before'),
						loading = $this.getRoleValue('loading') || '正在提交中，请稍后...',
						confirm = $this.getDataValue('post'),
						enter   = $this.getRoleValue('enter'),
						cancel  = $this.getRoleValue('cancel');
					// 加载中
					if ($this.data('status') === 'loading') {
						return false;
					}
					// 提交前回调
					if (before.length && false === eval(before + '.call($this);')) {
						return false;
					}
					// 提交
					if ($this.data('status') === 'submit') {
						$this.data('status', 'loading');
						$loading = $.dialog.pending(loading);
						$button.prop('disabled', true);
						return true;
					}
					// 确认操作
					if ($this.data('status') === 'pending') {
						if (confirm.length) {
							$.dialog.confirm(confirm, function () {
								// 确认回调
								if (enter.length && false === eval(enter + '.call($this);')) {
									return true;
								}
								$this.data('status', 'submit');
								$this.submit();
							}, function () {
								// 取消回调
								if (cancel.length && false === eval(cancel + '.call($this);')) {
									return true;
								}
								$this.data('status', 'pending');
							});
						} else {
							$this.data('status', 'submit');
							$this.submit();
						}
					}
					return false;
				},
				// 提交成功
				success : function (data) {
					var success = $this.getRoleValue('success');
					$.dialog.alert(data.info, function () {
						if (success.length && false === eval(success + '.call($this, data);')) {
							return true;
						}
						self.location.reload();
					}, 'succeed');
				},
				// 提交后
				error   : function (data) {
					var error = $this.getRoleValue('error');
					$.dialog.alert(data.info, function () {
						if (error) {
							eval(error + '.call($this, data)');
						}
					});
				},
				// 服务器接收成功
				after   : function (data) {
					var complete = $this.getRoleValue('complete');
					$loading.close();
					$button.prop('disabled', false);
					$this.data('status', 'pending');
					if (complete) {
						eval(complete + '.call($this, data)');
					}
				}
			});
		} else {
			$this.submitForm({
				before  : function () {
					var pending = $this.getRoleValue('loading') || '正在提交中，请稍后...';
					$loading    = $.dialog.pending(pending);
				},
				success : function (data) {
					$.parseCode(data);
				},
				error   : function (data) {
					$.dialog.alert(data.info, function () {
						$this.parseFormError(data);
					});
				},
				after   : function () {
					$loading.close();
				}
			});
		}
	});

	/**
	 * 简单搜索初始化
	 * @attr data-search 启动属性，值为附加搜索参数
	 * @attr role-search-select-value select的value内容，多个用,号隔开
	 * @attr role-search-select-text select的文本内容，多个用,号隔开
	 * @attr role-search-select-selected select选中项的值
	 * @attr role-search-accurate 是否精确搜索
	 * @attr role-search-keyword 搜索的关键词
	 * @attr role-search-action 搜索的action提交地址
	 * @attr role-search-extend 扩展的表单，通过jQuery selector 选择器获取对应的HTML
	 */
	$("[data-search]").each(function () {
		var $this       = $(this),
			parameter   = $this.getDataValue('search'),
			selectValue = $this.getRoleValue('search-select-value'),
			selectText  = $this.getRoleValue('search-select-text'),
			action      = $this.getRoleValue('search-action') || SELF_URL,
			extend      = $this.getRoleValue('search-extend'),
			offset      = $this.offset(),
			id          = 'SmallSearch_' + parseInt(offset.left) + '_' + parseInt(offset.top),
			template    = '',
			content     = $.trim($(this).find('[role-search="content"]').html()) || '',
			contentLeft = $.trim($(this).find('[role-search="content-left"]').html()) || '',
			right       = $.trim($(this).find('[role-search="right"]').html()) || '',
			hidden      = '';

		// 隐藏域
		var hiddenParams                    = $.parseURL(document.URL.replace(/\+/g, '%20')).params || {};
		var setValueParams                  = {};
		var filterKey                       = ['word', 'field', 'accurate'];
		if (window.URL_PATTERN_VALUE) {
			hiddenParams[window.URL_PATTERN_KEY] = window.URL_PATTERN_VALUE;
		}
		if (hiddenParams.hasOwnProperty(window.URL_PAGE_KEY)) {
			delete hiddenParams[window.URL_PAGE_KEY];
		}

		for (var key in hiddenParams) {
			key = decodeURIComponent(key);
			if (0 <= filterKey.indexOf(key)) {
				setValueParams[key] = hiddenParams[key];
				continue;
			}

			if (0 === key.indexOf('static[')) {
				setValueParams[key] = hiddenParams[key];
				continue;
			}

			hidden += '<input type="hidden" name="' + key + '" value="' + hiddenParams[key] + '"/>';
		}

		// 字段搜索
		var values  = selectValue.split(','),
			texts   = selectText.split(','),
			options = '';

		for (var i = 0; i < values.length; i++) {
			var value = $.trim(values[i]);
			if (!value.length) {
				continue;
			}

			var current = '';
			if (value == (setValueParams.field || '')) {
				current = ' selected';
			}
			options += '<option value="' + values[i] + '"' + current + '>' + (texts[i] || values[i]) + '</option>';
		}

		// 表单
		template += '<div class="panel-search">\
				<div class="panel-search-left icon icon-search"></div>\
				<div class="panel-search-right ' + (right ? '' : ' hide') + '">' + right + '\
					<div class="clearfix"></div>\
				</div>\
				<div class="panel-search-form">\
					<form action="' + action + '" method="get" class="form-inline" id="' + id + '">\
						' + hidden + contentLeft + '\
						<div class="form-group">\
							<select class="form-control" name="field">' + options + '</select>\
						</div>\
						<div class="form-group">\
							<input class="form-control" name="word" placeholder="请输入关键字"/>\
						</div>\
						<div class="checkbox">\
							<label>\
								<input type="checkbox" name="accurate" value="1"/>&nbsp;精确搜索\
							</label>\
						</div>' + content + '\
						<div class="form-group">\
							<button class="btn btn-info" type="submit"><i class="icon icon-search"></i> 搜索</button>\
							<a class="btn btn-default" href="' + action + '">显示全部</a>\
						</div>\
					</form>\
				</div>\
				<div class="clearfix"></div>\
			</div>';
		$this.html(template);

		// 设置值
		for (key in setValueParams) {
			value = setValueParams[key] || '';

			var $input = $this.find('[name="' + key + '"]');
			switch ($input[0].tagName) {
				case 'INPUT':
					switch ($input.attr('type')) {
						case 'radio':
							$input.each(function () {
								if ($(this).val() === value) {
									$(this).prop('checked', true);
								} else {
									$(this).prop('checked', false);
								}
							});
							break;
						case 'checkbox':
							value = parseInt(value);
							value = isNaN(value) ? 0 : value;
							if (value > 0) {
								$input.prop('checked', true);
							} else {
								$input.prop('checked', false);
							}
							break;
						default:
							$input.val(value);
					}
					break;
				case 'SELECT':
					$input.val(value);
					break;
			}
		}
	});

	/**
	 * 自动弹窗打开iframe
	 * @attr data-iframe 启动属性，值为要打开的URL
	 * @attr role-close 当前弹窗关闭时触发的回调事件
	 */
	$("[data-iframe]").each(function () {
		$(this).on('click', function () {
			var $this                       = $(this),
				link                        = $this.getDataValue('iframe'),
				lock                        = $this.getRoleValue('lock'),
				close                       = $this.getRoleValue('close');
			$.dialog.top['@ARTDIALOG.DATA'] = {};
			$.dialog.open(link, {
				close   : function () {
					if (close.length && false === eval(close + '.call(this, $this)')) {
						return false;
					}
				}, lock : lock ? true : false
			});
		});
	});

	/**
	 * 自动添加组件
	 * @attr data-add-item 启动属性，值为添加组件的容器selector
	 * @attr role-add-item-callback 当每个容器被添加到容器中的回调事件，内容对象this指向当前被添加经来的容器对象，参数line代表当前容器的index
	 * @attr role-add-item-btn 执行添加item的按钮selector
	 * @attr role-add-item-max 允许的最大添加的条数，0为不限，默认为不限
	 * @attr role-add-item-init 初始化的时候如果组件容器item为空的话默认初始化多少条，默认为1条
	 * @children 子容器功能属性
	 *        @attr role-add-item="item" item容器必须包含的属性
	 *        @attr role-add-item="remove" item容器中删除按钮的属性
	 *        @attr role-add-item="prev" item容器中上移按钮的属性
	 *        @attr role-add-item="next" item容器中下移按钮的属性
	 *        @var [num] 当前容器的index变量
	 */
	$('[data-auto="add-item"]').each(function () {
		$(this).adminAddItem();
	});

	/**
	 * 打开路由页面
	 */
	$(document).on('click', '[data-route]', function () {
		var $this   = $(this);
		var $target = $($this.attr('data-route'));
		$.dialog.open(ADMIN_URL + 'index.php?g=common&m=index&a=scheme', {
			close : function () {
				var url = $.dialog.data('url');
				$.dialog.data('url', '');

				if (url.length > 0) {
					$target.val(url);
				}
			},
			lock  : true
		});
	});
});
/**
 * 后台面板初始化执行的内容
 */
$(document).ready(function () {
	if (self != top) {
		return;
	}

	var $nav           = $('#nav');
	var $menu          = $('#menu');
	var $leftBox       = $('#leftBox');
	var $menuFatherBox = $nav.find('.menu-father-box');
	var $menuLiList    = $menu.find('li');

	// 导航栏切换
	$menu.find('a').on('click', function () {
		var $me     = $(this);
		var $target = $('#' + $(this).attr('data-target'));
		var $ul     = $target.next('ul');
		if ($ul.length) {
			$menuLiList.removeClass('active');
			$me.parent('li').addClass('active');
			$menuFatherBox.addClass('hide');
			$ul.removeClass('hide');
		}
	});

	// 保存菜单展开关闭状态
	var saveNavStatus = function (id, isAdd) {
		var saves = $.cookie('admin_menu_status_' + USER_ID);
		if (!saves) {
			saves = '_';
		}
		if (saves.indexOf('_' + id + '_') === -1 && isAdd) {
			saves += id + '_';
		} else if (false === isAdd) {
			saves = saves.replace(id + '_', '');
		}
		$.cookie('admin_menu_status_' + USER_ID, saves, {path : '/', expires : 365});
	};

	// 解析菜单展开关闭状态
	var parseNavStatus = function () {
		var saves = $.cookie('admin_menu_status_' + USER_ID);
		if (!saves) {
			$nav.find('a.menu-father-a').trigger('click');
			return false;
		}
		var array  = saves.split('_');
		var length = array.length;
		for (var i = 0; i < length; i++) {
			var id = parseInt(array[i]);
			if (!id) {
				continue;
			}
			var $item = $('#menu_item_' + id);
			if ($item.length) {
				$item.find('a.menu-father-a').trigger('click');
			}
		}
	};

	// 导航栏展开关闭
	$nav.on('click', 'a.menu-father-a', function () {
		var $me = $(this);
		var $li = $me.parent('li');
		var $ul = $me.next('ul');
		var id  = $li.attr('data-id');

		if (parseInt($ul.attr('data-show'))) {
			$ul.slideUp(0, function () {
				$(this).attr('data-show', 0);
				$me.find('em').removeClass('icon-rotate-90');
				saveNavStatus(id, true);
			});
		} else {
			$ul.slideDown(0, function () {
				$(this).attr('data-show', 1);
				$me.find('em').addClass('icon-rotate-90');
				saveNavStatus(id, false);
			});
		}
	});

	parseNavStatus();

	// 导航栏侧边
	var $mobileBar         = $('#mobileBar');
	var $mobileBarRightBtn = $mobileBar.find('a.pull-right');
	var $body              = $('body');
	var bodyId             = $body.attr('id');
	var $contentBox        = $('#contentBox');
	var $layoutBg          = $('#layoutBg');
	var $content           = $('#content');
	$mobileBarRightBtn.on('click', function () {
		if ($mobileBarRightBtn.attr('data-open') == 1) {
			$contentBox.removeClass('layout-nav-open');
			$layoutBg.removeClass('layout-nav-open');
			$leftBox.removeClass('layout-nav-open');
			$body.removeClass('layout-nav-open');
			$mobileBarRightBtn.attr('data-open', 0);
			$mobileBarRightBtn.find('i').removeClass('icon-close').addClass('icon-list-ul');
			$contentBox.height('auto');
		} else {
			// 高度
			var height        = $(window).height();
			var headerHeight  = $('#header').height();
			var contentHeight = $contentBox.height();
			if (contentHeight + headerHeight < height) {
				$contentBox.height(height - headerHeight);
			}

			$contentBox.addClass('layout-nav-open');
			$leftBox.addClass('layout-nav-open');
			$body.addClass('layout-nav-open');
			$layoutBg.addClass('layout-nav-open');
			$mobileBarRightBtn.attr('data-open', 1);
			$mobileBarRightBtn.find('i').removeClass('icon-list-ul').addClass('icon-close');
		}
	});
	$layoutBg.on('click', function () {
		$mobileBarRightBtn.trigger('click');
	});

	$.autoScroll = function () {
		var scrollData = JSON.parse($.cookie('scrollData') || '{}');
		var timer      = null;
		$content.on('scroll', function () {
			if (timer != null) {
				clearTimeout(timer);
			}
			timer = setTimeout(function () {
				scrollData[bodyId] = $content.scrollTop();
				var keyList        = [];
				for (var key in scrollData) {
					keyList.push(key);
				}
				var keyLength = keyList.length;
				var maxLength = 10;
				if (keyLength > maxLength) {
					for (var i = 0; i < keyLength - maxLength; i++) {
						delete scrollData[keyList[i]];
					}
				}

				$.cookie('scrollData', JSON.stringify(scrollData), {path : '/'});
			}, 100);
		});
		var scrollTop = scrollData[bodyId] || 0;
		if (scrollTop > 0) {
			$content.scrollTop(scrollTop);
		}
	};

	// 滚动条定位
	if (window.SAVE_SCROLL === true) {
		$.autoScroll();
	}
});